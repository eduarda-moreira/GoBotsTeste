/*------------------------------------------------------------------------*/
/*                   WEB SPEECH API EM JAVASCRIPT                         */
/*------------------------------------------------------------------------*/


//Verificar se o navegador suporta a API
if ('speechSynthesis' in window) {
}else{
  alert("Desculpe, seu navegador não suporta o Web Speech API!");
}

var el = document.getElementById ("falar"); //Pega o Id "falar" que está no button do form.html e armazena na variável "el"
if(el){
    el.onclick = APIFunction //Caso o "el", isto é, Id "falar", for clicado a função "APIFunction" será executada
}

function APIFunction() {
    var txt = document.getElementById("text-input"); //Pega o Id "text-input" que está no <h3> do form.html e armazena na variável "txt"
    var txt2 = txt.textContent || txt.innerText; //Filtra para armazenar apenas o conteúdo de texto da variável "txt" na variável "txt2"
    var msg = new SpeechSynthesisUtterance(txt2); //Síntese da fala usando a variável "txt2"
    msg.lang = "pt-BR" //Define a língua como português - brasileiro
    window.speechSynthesis.speak(msg); //Reproduz a fala do texto
}