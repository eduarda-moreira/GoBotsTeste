from flask import Flask, url_for, render_template, request
import os

app = Flask(__name__)

#Dicionário com o que deve ser traduzido
dicionario = {"td":"tudo","Td":"Tudo", "TD": "TUDO",
              "q": "que", "Q": "QUE", "Q": "Que",
              "bm": "bem", "Bm": "Bem", "BM": "BEM",
              "qd":"quando", "Qd":"Quando", "QD":"QUANDO",
              "qnd":"quando", "Qnd":"Quando","QND":"QUANDO",
              "qdo":"quando", "Qdo":"Quando", "QDO":"QUANDO",
              "qto":"quanto", "Qto":"Quanto", "QTO":"QUANTO",
               "eh": "é", "Eh": "É", "EH": "É",
              "obg": "obrigado", "Obg": "Obrigado", "OBG": "OBRIGADO",
              "tb": "também", "Tb": "Também", "TB": "TAMBÉM",
              "vc": "você", "Vc":"Você", "VC":"VOCÊ"}

#Home page
@app.route("/")
def home():
    return render_template("form.html")

#Page com o formulário/textbox
@app.route("/form", methods=["POST", "GET"])
def form():
    #Se o método chamado for o POST
    if request.method == "POST":
        #Através do request, pegamos o que foi escrito no form HTML de nome "frase"
        user = request.form["frase"]
        #Condição para dar split na string e traduzir as palavras
        texto = ' '.join([dicionario.get(i, i) for i in user.split()])
        #Retorna o resultado
        return render_template("form.html", texto = texto)
    #Se o método chamada não for o POST, a página não muda
    #Questão simbólica mesmo, porque sabemos que é um POST
    else:
        return render_template("form.html", texto="")

#Condição para executar o código apenas se você estiver no arquivo
if __name__ == "__main__":
    app.run(debug=True)

